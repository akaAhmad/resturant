import 'package:flutter/material.dart';

class notificationScreen extends StatelessWidget {
  const notificationScreen ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}