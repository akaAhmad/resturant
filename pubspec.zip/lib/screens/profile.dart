import 'package:flutter/material.dart';

class profileScreen extends StatelessWidget {
  const profileScreen ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}